import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import SummaryApi from "../common"; // Assuming this has your API endpoints
import displayINRCurrency from "../helpers/displayCurrency";
import { toast } from "react-toastify";

const CheckoutPage = () => {
  const [cartData, setCartData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [totalPrice, setTotalPrice] = useState(0);
  const navigate = useNavigate();
  const fetchCartData = async () => {
    try {
      const response = await fetch(SummaryApi.addToCartProductView.url, {
        method: SummaryApi.addToCartProductView.method,
        credentials: "include",
      });
      const responseData = await response.json();
      if (responseData.success) {
        setCartData(responseData.data);
        setTotalPrice(
          responseData.data.reduce(
            (sum, item) => sum + item.product.price * item.quantity,
            0
          )
        );
        setLoading(false);
      }
    } catch (error) {
      console.error("Failed to fetch cart data:", error);
    }
  };

  useEffect(() => {
    fetchCartData();
  }, []);

  const handleCheckout = async () => {
    const response = await fetch(SummaryApi.createOrder.url, {
      method: SummaryApi.createOrder.method,
      credentials: "include",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        products: cartData,
        totalAmount: totalPrice,
      }),
    });
    const responseData = await response.json();
    if (responseData.success) {
      toast.success(responseData.message);
      navigate("/order-summary"); // Navigate to confirmation page
    } else {
      toast.error(responseData.message);
    }
  };

  if (loading)
    return (
      <div className="flex items-center justify-center h-screen">
        Loading...
      </div>
    );

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-4xl font-bold mb-8">Checkout</h1>
      <div className="bg-white rounded shadow-lg p-8">
        <h2 className="text-2xl mb-4">Products</h2>
        <table className="w-full">
          <thead>
            <tr className="bg-gray-200 text-gray-900">
              <th className="px-4 py-2">Product</th>
              <th className="px-4 py-2">Price</th>
              <th className="px-4 py-2">Quantity</th>
              <th className="px-4 py-2">Total</th>
            </tr>
          </thead>
          <tbody>
            {cartData.map((item) => (
              <tr key={item.productId} className="border-b">
                <td className="px-4 py-2">{item.product.productName}</td>
                <td className="px-4 py-2">
                  {displayINRCurrency(item.product.price)}
                </td>
                <td className="px-4 py-2">{item.quantity}</td>
                <td className="px-4 py-2">
                  {displayINRCurrency(item.product.price * item.quantity)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        <div className="flex justify-end mt-4">
          <div className="text-2xl font-semibold mr-4">
            Total: {displayINRCurrency(totalPrice)}
          </div>

          <button
            onClick={handleCheckout}
            className="bg-blue-600 text-white px-4 py-2 rounded"
          >
            Place Order
          </button>
        </div>
      </div>
    </div>
  );
};

export default CheckoutPage;
