import React, { useEffect, useState } from "react";
import { MdCancel } from "react-icons/md";
import { useSelector } from "react-redux";
import ROLE from "../common/role";
import SummaryApi from "../common";
import displayUSDCurrency from "../helpers/displayCurrency";
import { toast } from "react-toastify";

const OrderSummary = () => {
  const user = useSelector((state) => state?.user?.user);
  const [orders, setOrders] = useState([]);

  const fetchOrders = async () => {
    const response = await fetch(SummaryApi.orderSummary.url, {
      method: SummaryApi.orderSummary.method,
      credentials: "include",
      headers: {
        "content-type": "application/json",
      },
    });
    const responseData = await response.json();
    if (responseData.success) {
      setOrders(responseData.data);
    }
  };

  useEffect(() => {
    fetchOrders();
  }, []);

  const handleDeleteOrder = async (orderId) => {
    const response = await fetch(`${SummaryApi.deleteOrder.url}/${orderId}`, {
      method: "GET",
      credentials: "include",
    });
    const responseData = await response.json();
    if (responseData.success) {
      toast.success(responseData.message);
      fetchOrders();
    } else {
      toast.error(responseData.message);
    }
  };

  const updateOrderStatus = async (orderId, status) => {
    const response = await fetch(
      `${SummaryApi.updateOrderStatus.url}/${orderId}`,
      {
        method: "POST",
        credentials: "include",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ status }),
      }
    );
    const responseData = await response.json();
    if (responseData.success) {
      toast.success(responseData.message);
      fetchOrders();
    } else {
      toast.error(responseData.message);
    }
  };

  const getStatusStyle = (status) => {
    switch (status) {
      case "PENDING":
        return "text-yellow-500";
      case "COMPLETED":
        return "text-green-500";
      case "CANCELLED":
        return "text-red-500";
      default:
        return "";
    }
  };

  return (
    <div className="container mx-auto">
      <h1 className="text-2xl font-bold my-4">Order Summary</h1>
      <div className="overflow-x-auto">
        <table className="min-w-full bg-white shadow-md rounded">
          <thead>
            <tr className="bg-red-400">
              <th className="py-2 px-4 border-b">Order ID</th>
              <th className="py-2 px-4 border-b">Total Amount</th>
              <th className="py-2 px-4 border-b">Status</th>
              <th className="py-2 px-4 border-b">Products</th>
              <th className="py-2 px-4 border-b">Actions</th>
            </tr>
          </thead>
          <tbody>
            {orders.length ? (
              orders.map((order) => (
                <tr className="hover:bg-gray-100" key={order.id}>
                  <td className="py-2 px-4 border-b text-center">{order.id}</td>
                  <td className="py-2 px-4 border-b text-center">
                    {displayUSDCurrency(order.totalAmount)}
                  </td>
                  <td
                    className={`py-2 px-4 border-b text-center ${getStatusStyle(
                      order.status
                    )}`}
                  >
                    {order.status}
                  </td>
                  <td className="py-2 px-4 border-b">
                    <ul className="list-disc list-inside">
                      {order.orderItems?.map((item) => (
                        <li key={item.productId}>
                          {item.product.productName} - {item.quantity} x ₹
                          {item.price}
                        </li>
                      ))}
                    </ul>
                  </td>
                  <td className="py-2 px-4 border-b text-center">
                    {user?.role === ROLE.GENERAL &&
                      order.status === "PENDING" && (
                        <button
                          onClick={() => handleDeleteOrder(order.id)}
                          className="text-red-500 flex items-center"
                        >
                          <MdCancel /> Cancel
                        </button>
                      )}
                    {user?.role === ROLE.ADMIN && (
                      <div>
                        <button
                          onClick={() =>
                            updateOrderStatus(order.id, "COMPLETED")
                          }
                          className="bg-green-500 text-white px-2 py-1 m-1 rounded"
                        >
                          Accept
                        </button>
                        <button
                          onClick={() =>
                            updateOrderStatus(order.id, "CANCELLED")
                          }
                          className="bg-red-500 text-white px-2 py-1 m-1 rounded"
                        >
                          Decline
                        </button>
                      </div>
                    )}
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="5" className="text-center py-4 text-gray-500">
                  No orders found.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default OrderSummary;
