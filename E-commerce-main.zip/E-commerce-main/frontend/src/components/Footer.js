import React from 'react'

const Footer = () => {
  return (
    <footer className='bg-gray-700 text-white'>
      <div className='container mx-auto p-6'>
        <div className='flex justify-between'>
          <div>
            <h4 className='font-bold mb-2'>Company</h4>
            <ul>
              <li><a href='#' className='hover:underline'>About Us</a></li>
              <li><a href='#' className='hover:underline'>Careers</a></li>
              <li><a href='#' className='hover:underline'>Press</a></li>
            </ul>
          </div>
          <div>
            <h4 className='font-bold mb-2'>Support</h4>
            <ul>
              <li><a href='#' className='hover:underline'>Contact Us</a></li>
              <li><a href='#' className='hover:underline'>FAQs</a></li>
              <li><a href='#' className='hover:underline'>Shipping & Returns</a></li>
            </ul>
          </div>
          <div>
            <h4 className='font-bold mb-2'>Follow Us</h4>
            <ul className='flex space-x-4'>
              <li><a href='#' className='hover:text-gray-400'>Facebook</a></li>
              <li><a href='#' className='hover:text-gray-400'>Twitter</a></li>
              <li><a href='#' className='hover:text-gray-400'>Instagram</a></li>
            </ul>
          </div>
        </div>
        <div className='text-center mt-6'>
          <p>&copy; 2023 E-Commerce, Inc. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}

export default Footer