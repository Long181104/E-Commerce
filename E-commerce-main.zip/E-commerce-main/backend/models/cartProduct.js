const { Model, DataTypes } = require("sequelize");
const { sequelize } = require("../config/SQLize");
const userModel = require("./userModel");
const productModel = require("./productModel");

class addToCartModel extends Model {}

addToCartModel.init(
  {
    userId: {
      type: DataTypes.INTEGER,
      references: {
        model: userModel,
        key: "id",
      },
      allowNull: false,
    },
    productId: {
      type: DataTypes.INTEGER,
      references: {
        model: productModel,
        key: "id",
      },
      allowNull: false,
    },
    quantity: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
  },
  {
    sequelize,
    timestamps: true,
  }
);


module.exports = addToCartModel;

