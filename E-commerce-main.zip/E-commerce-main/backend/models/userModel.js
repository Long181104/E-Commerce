
const { Model, DataTypes } = require("sequelize");
const { sequelize } = require("../config/SQLize");

class userModel extends Model {}

userModel.init(
  {
    name: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    email: {
      type: DataTypes.STRING,
      unique: true,
      allowNull: false,
    },
    password: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    profilePic: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    role: {
      type: DataTypes.ENUM("GENERAL", "ADMIN"), // Define roles
      defaultValue: "GENERAL",
    },
  },
  {
    sequelize,
    timestamps: true,
  }
);

module.exports = userModel;
