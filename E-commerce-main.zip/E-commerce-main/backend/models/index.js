const userModel = require("./userModel");
const productModel = require("./productModel");
const orderModel = require("./oderModel");
const addToCartModel = require("./cartProduct");
const orderItem = require("./oderItemModel");


// Setup associations
userModel.hasMany(addToCartModel, { foreignKey: "userId" });
addToCartModel.belongsTo(userModel, { foreignKey: "userId" });

productModel.hasMany(addToCartModel, { foreignKey: "productId", as: "addToCart" });
addToCartModel.belongsTo(productModel, { foreignKey: "productId", as: "product" });

userModel.hasMany(orderModel, { foreignKey: "userId" });
orderModel.belongsTo(userModel, { foreignKey: "userId" });

orderModel.hasMany(orderItem, { foreignKey: "orderId" });
orderItem.belongsTo(orderModel, { foreignKey: "orderId" });

productModel.hasMany(orderItem, { foreignKey: "productId" });
orderItem.belongsTo(productModel, { foreignKey: "productId" });

module.exports = {
  userModel,
  productModel,
  orderModel,
  addToCartModel,
  orderItem
 };
