const { Model, DataTypes } = require("sequelize");
const { sequelize } = require("../config/SQLize");
const userModel = require("./userModel");

class orderModel extends Model {}

orderModel.init(
  {
    userId: {
      type: DataTypes.INTEGER,
      references: {
        model: userModel,
        key: "id",
      },
      allowNull: false,
    },
    totalAmount: {
      type: DataTypes.DECIMAL(10, 2),
      allowNull: false,
    },
    status: {
      type: DataTypes.ENUM("PENDING", "COMPLETED", "CANCELLED"),
      defaultValue: "PENDING",
    },
  },
  {
    sequelize,
    timestamps: true,
  }
);

module.exports = orderModel;

