const { Model, DataTypes } = require("sequelize");
const orderModel = require("./oderModel");
const { sequelize } = require("../config/SQLize");
const productModel = require("./productModel");

class OrderItem extends Model {}

OrderItem.init(
  {
    orderId: {
      type: DataTypes.INTEGER,
      references: {
        model: orderModel,
        key: "id",
      },
      allowNull: false,
    },
    productId: {
      type: DataTypes.INTEGER,
      references: {
        model: productModel,
        key: "id",
      },
      allowNull: false,
    },
    quantity: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
  },
  {
    sequelize,
    timestamps: true,
  }
);

module.exports = OrderItem;
