drop database if EXISTS shop_here

create  database shop_here

use shop_here

-- Drop tables if they exist to avoid duplication errors
DROP TABLE IF EXISTS OrderItems;
DROP TABLE IF EXISTS addToCartModels;
DROP TABLE IF EXISTS orderModels;
DROP TABLE IF EXISTS productModels;
DROP TABLE IF EXISTS userModels;

-- Create `users` table


CREATE TABLE userModels (
  id INT PRIMARY KEY IDENTITY(1,1),
  name NVARCHAR(255) NOT NULL,
  email NVARCHAR(255) UNIQUE NOT NULL,
  password NVARCHAR(255) NOT NULL,
  role NVARCHAR(50) NOT NULL
);

-- Insert data into `users` table
INSERT INTO userModels (name, email, password, role) VALUES
  ('John Doe', 'john@example.com', 'Admin123@', 'ADMIN'),
  ('Jane Smith', 'jane@example.com', 'Employee123@', 'GENERAL');

-- Create `products` table
CREATE TABLE productModels (
  id INT PRIMARY KEY IDENTITY(1,1),
  productName NVARCHAR(255) NOT NULL,
  brandName NVARCHAR(255) NOT NULL,
  category NVARCHAR(255),
  productImage NVARCHAR(MAX),
  description NVARCHAR(MAX),
  price DECIMAL(10, 2) NOT NULL,
  sellingPrice DECIMAL(10, 2) NOT NULL
);

-- Insert data into `products` table
INSERT INTO productModels (productName, brandName, category, productImage, description, price, sellingPrice) VALUES
  ('Product 1', 'Brand A', 'Category 1', '', 'Description for Product 1', 100, 80),
  ('Product 2', 'Brand B', 'Category 2', '', 'Description for Product 2', 150, 120);

-- Create `orders` table
CREATE TABLE orderModels (
  id INT PRIMARY KEY IDENTITY(1,1),
  userId INT NOT NULL,
  totalAmount DECIMAL(10, 2) NOT NULL,
  FOREIGN KEY (userId) REFERENCES userModels(id) ON DELETE CASCADE
);

-- Insert data into `orders` table
INSERT INTO orderModels (userId, totalAmount) VALUES
  (1, 200),
  (2, 150);

-- Create `add_to_cart` table
CREATE TABLE addToCartModels (
  id INT PRIMARY KEY IDENTITY(1,1),
  userId INT NOT NULL,
  productId INT NOT NULL,
  quantity INT NOT NULL,
  FOREIGN KEY (userId) REFERENCES userModels(id) ON DELETE CASCADE,
  FOREIGN KEY (productId) REFERENCES productModels(id) ON DELETE CASCADE
);

-- Insert data into `add_to_cart` table
INSERT INTO addToCartModels (userId, productId, quantity) VALUES
  (1, 1, 2),
  (2, 2, 1);

-- Create `order_items` table
CREATE TABLE OrderItems (
  id INT PRIMARY KEY IDENTITY(1,1),
  orderId INT NOT NULL,
  productId INT NOT NULL,
  quantity INT NOT NULL,
  FOREIGN KEY (orderId) REFERENCES orderModels(id) ON DELETE CASCADE,
  FOREIGN KEY (productId) REFERENCES productModels(id) ON DELETE CASCADE
);

-- Insert data into `order_items` table
INSERT INTO OrderItems (orderId, productId, quantity) VALUES
  (1, 1, 1),
  (2, 2, 2);

-- Add the profilePic column
ALTER TABLE userModels
ADD profilePic NVARCHAR(255) NULL;

-- Add createdAt and updatedAt timestamp columns
ALTER TABLE userModels
ADD createdAt DATETIME2 DEFAULT SYSDATETIME() NOT NULL,
    updatedAt DATETIME2 DEFAULT SYSDATETIME() NOT NULL;

ALTER TABLE addToCartModels
ADD createdAt DATETIME2 DEFAULT SYSDATETIME() NOT NULL,
    updatedAt DATETIME2 DEFAULT SYSDATETIME() NOT NULL;

ALTER TABLE productModels
ADD createdAt DATETIME2 DEFAULT SYSDATETIME() NOT NULL,
    updatedAt DATETIME2 DEFAULT SYSDATETIME() NOT NULL;

ALTER TABLE orderModels
ADD 
    status varchar(10) NOT NULL DEFAULT 'PENDING',
    createdAt DATETIME2 DEFAULT SYSDATETIME() NOT NULL,
    updatedAt DATETIME2 DEFAULT SYSDATETIME() NOT NULL;

ALTER TABLE OrderItems
ADD createdAt DATETIME2 DEFAULT SYSDATETIME() NOT NULL,
    updatedAt DATETIME2 DEFAULT SYSDATETIME() NOT NULL;

-- If you want to update the updatedAt column on every update, you can use a trigger (if necessary), but it's not strictly needed for the schema change.

INSERT INTO productModels (productName, brandName, category, productImage, description, price, sellingPrice)
VALUES
    -- Airpods Category
    ('Airpods Pro', 'Apple', 'airpods', 'image_url_1.jpg,image_url_2.jpg', 'Wireless noise-canceling headphones.', 250.00, 200.00),
    ('Airpods Max', 'Apple', 'airpods', 'image_url_3.jpg,image_url_4.jpg', 'Over-ear headphones with immersive audio.', 550.00, 450.00),

    -- Watches Category
    ('Galaxy Watch 4', 'Samsung', 'watches', 'image_url_5.jpg,image_url_6.jpg', 'Smartwatch with fitness tracking.', 300.00, 250.00),
    ('Apple Watch Series 7', 'Apple', 'watches', 'image_url_7.jpg,image_url_8.jpg', 'Latest smartwatch from Apple with a larger display.', 400.00, 350.00),

    -- Mobiles Category
    ('iPhone 13', 'Apple', 'mobiles', 'image_url_9.jpg,image_url_10.jpg', 'Latest iPhone with A15 Bionic chip.', 999.00, 899.00),
    ('Samsung Galaxy S21', 'Samsung', 'mobiles', 'image_url_11.jpg,image_url_12.jpg', 'Premium smartphone with excellent camera.', 799.00, 699.00),

    -- Speakers Category
    ('Sonos One', 'Sonos', 'speakers', 'image_url_13.jpg,image_url_14.jpg', 'Smart speaker with excellent sound quality.', 199.00, 149.00),
    ('Bose SoundLink', 'Bose', 'speakers', 'image_url_15.jpg,image_url_16.jpg', 'Portable Bluetooth speaker with great bass.', 129.00, 99.00),

    -- Mouse Category
    ('Logitech MX Master 3', 'Logitech', 'Mouse', 'image_url_17.jpg,image_url_18.jpg', 'Advanced wireless mouse with customizable buttons.', 99.00, 79.00),
    ('Razer DeathAdder V2', 'Razer', 'Mouse', 'image_url_19.jpg,image_url_20.jpg', 'Ergonomic gaming mouse with high precision.', 69.00, 49.00),

    -- Refrigerator Category
    ('LG Smart Refrigerator', 'LG', 'refrigerator', 'image_url_21.jpg,image_url_22.jpg', 'Smart refrigerator with Wi-Fi connectivity.', 1200.00, 1000.00),
    ('Samsung French Door', 'Samsung', 'refrigerator', 'image_url_23.jpg,image_url_24.jpg', 'Spacious refrigerator with flexible storage.', 1500.00, 1300.00),

    -- Televisions Category
    ('Samsung QLED TV', 'Samsung', 'televisions', 'image_url_25.jpg,image_url_26.jpg', '4K UHD TV with Quantum Dot technology.', 1500.00, 1200.00),
    ('LG OLED TV', 'LG', 'televisions', 'image_url_27.jpg,image_url_28.jpg', 'Incredible picture quality with self-lighting OLED.', 1800.00, 1500.00),

    -- Camera Category
    ('Canon EOS R5', 'Canon', 'camera', 'image_url_29.jpg,image_url_30.jpg', 'Mirrorless camera with 45MP sensor.', 3899.00, 3499.00),
    ('Nikon Z6 II', 'Nikon', 'camera', 'image_url_31.jpg,image_url_32.jpg', 'Full-frame mirrorless camera with 24.5MP sensor.', 1999.00, 1799.00),

    -- Earphones Category
    ('Sony WF-1000XM4', 'Sony', 'earphones', 'image_url_33.jpg,image_url_34.jpg', 'Noise-canceling true wireless earphones.', 280.00, 230.00),
    ('Jabra Elite 75t', 'Jabra', 'earphones', 'image_url_35.jpg,image_url_36.jpg', 'Compact true wireless earbuds with great sound.', 180.00, 150.00),

    -- Trimmers Category
    ('Philips Norelco Trimmer', 'Philips', 'trimmers', 'image_url_37.jpg,image_url_38.jpg', 'Precision trimmer for beard and hair.', 49.00, 39.00),
    ('Braun Beard Trimmer', 'Braun', 'trimmers', 'image_url_39.jpg,image_url_40.jpg', 'High precision beard trimmer with adjustable settings.', 59.00, 49.00);