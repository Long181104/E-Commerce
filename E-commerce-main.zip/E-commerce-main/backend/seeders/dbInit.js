const bcrypt = require("bcryptjs");
const {
  userModel,
  productModel,
  orderModel,
  addToCartModel,
  orderItem,
} = require("../models/index");

const initialData = async () => {
  try {
    // Check and seed users
    const userCount = await userModel.count();
    if (userCount === 0) {
      const users = [
        {
          name: "John Doe",
          email: "john@example.com",
          password: bcrypt.hashSync("Admin123@", 10),
          role: "GENERAL",
        },
        {
          name: "Jane Smith",
          email: "jane@example.com",
          password: bcrypt.hashSync("Employee123@", 10),
          role: "GENERAL",
        },
      ];
      await userModel.bulkCreate(users);
      console.log("Users seeded.");
    }

    // Check and seed products
    const productCount = await productModel.count();
    if (productCount === 0) {
      const products = [
        {
          productName: "Product 1",
          brandName: "Brand A",
          category: "Category 1",
          productImage: [],
          description: "Description for Product 1",
          price: 100,
          sellingPrice: 80,
        },
        {
          productName: "Product 2",
          brandName: "Brand B",
          category: "Category 2",
          productImage: [],
          description: "Description for Product 2",
          price: 150,
          sellingPrice: 120,
        },
      ];
      await productModel.bulkCreate(products);
      console.log("Products seeded.");
    }

    // Check and seed orders
    const orderCount = await orderModel.count();
    if (orderCount === 0) {
      const orders = [
        { userId: 1, totalAmount: 200 },
        { userId: 2, totalAmount: 150 },
      ];
      await orderModel.bulkCreate(orders);
      console.log("Orders seeded.");
    }

    // Check and seed add to cart
    const cartCount = await addToCartModel.count();
    if (cartCount === 0) {
      const carts = [
        { userId: 1, productId: 1, quantity: 2 },
        { userId: 2, productId: 2, quantity: 1 },
      ];
      await addToCartModel.bulkCreate(carts);
      console.log("Carts seeded.");
    }

    // Check and seed order items
    const orderItemCount = await orderItem.count();
    if (orderItemCount === 0) {
      const orderItems = [
        { orderId: 1, productId: 1, quantity: 1 },
        { orderId: 2, productId: 2, quantity: 2 },
      ];
      await orderItem.bulkCreate(orderItems);
      console.log("Order Items seeded.");
    }
  } catch (error) {
    console.error("Error during initial data seeding:", error);
  }
};

// initialData();

