const express = require("express");
const cors = require("cors");
const cookieParser = require("cookie-parser");
require("dotenv").config();
// const { connectDB, sequelize } = require("./config/db");
const router = require("./routes");
// const dbInit = require("./seeders/dbInit");

const app = express();
app.use(
  cors({
    origin: process.env.FRONTEND_URL,
    credentials: true,
  })
);
app.use(express.json());
app.use(cookieParser());

app.use("/api", router);

const PORT = 8080 || process.env.PORT;

const server = app.listen(PORT, async () => {
  console.log(`Listening on port ${PORT}`, "INFO", "Server");
});

