const { addToCartModel } = require("../../models");

const deleteAddToCartProduct = async (req, res) => {
  try {
    const currentUserId = req.userId;
    const addToCartProductId = req.body.id; // Adjusted to `id` to match Sequelize usage.

    // Delete product using Sequelize
    const deletedRows = await addToCartModel.destroy({
      where: {
        id: addToCartProductId,
        userId: currentUserId,
      },
    });

    if (deletedRows === 0) {
      return res.json({
        message: "Product not found in cart or already deleted",
        error: true,
        success: false,
      });
    }

    res.json({
      message: "Product Deleted From Cart",
      error: false,
      success: true,
      data: { id: addToCartProductId },
    });
  } catch (err) {
    res.json({
      message: err?.message || err,
      error: true,
      success: false,
    });
  }
};

module.exports = deleteAddToCartProduct;
