const { addToCartModel } = require("../../models");

const addToCartController = async (req, res) => {
  try {
    const { productId } = req.body;
    const currentUser = req.userId;
    console.log("productId", productId, "currentUser", currentUser);

    // Check if the product is already in the cart for the current user
    const isProductAvailable = await addToCartModel.findOne({
      where: {
        productId: productId,
        userId: currentUser, // Ensure we check for the current user
      },
    });

    if (isProductAvailable) {
      return res.status(400).json({
        message: "Already exists in Add to cart",
        success: false,
        error: true,
      });
    }

    // Create a new cart entry
    const newAddToCart = await addToCartModel.create({
      userId: currentUser,
      productId: productId,
      quantity: 1,
    });

    return res.json({
      data: newAddToCart,
      message: "Product Added to Cart",
      success: true,
      error: false,
    });
  } catch (err) {
    console.error("Error adding to cart:", err); // Log the error for debugging
    return res.status(500).json({
      message: err.message,
      error: true,
      success: false,
    });
  }
};

module.exports = addToCartController;

