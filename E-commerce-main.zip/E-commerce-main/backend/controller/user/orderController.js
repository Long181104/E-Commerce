const {
  addToCartModel,
  userModel,
  productModel,
  orderModel,
  orderItem,
} = require("../../models");

const { Op, or } = require("sequelize");

const createOrder = async (req, res) => {
  try {
    const userId = req.userId;
    const { products, totalAmount } = req.body;

    // Create the order
    const order = await orderModel.create({
      userId,
      totalAmount,
      status: "PENDING",
    });

    // Loop through products to create order items
    const orderItems = products.map((product) => ({
      orderId: order.id,
      productId: product.product.id,
      quantity: product.quantity,
    }));
    await orderItem.bulkCreate(orderItems);

    // remove products from cart
    await addToCartModel.destroy({
      where: {
        userId,
        productId: {
          [Op.in]: products.map((product) => product.product.id),
        },
      },
    });

    res.status(201).json({
      success: true,
      message: "Order placed successfully",
      data: order,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Something went wrong... Please try again",
    });
  }
};

const getOrderSummary = async (req, res) => {
  try {
    const userId = req.userId;

    console.log("first", userId);

    const user = await userModel.findByPk(userId);

    if (!user) {
      return res.status(404).json({
        message: "User not found",
        error: true,
        success: false,
      });
    }

    if (user.role === "GENERAL") {
      const orders = await orderModel.findAll({
        where: {
          userId,
        },
      });

      res.status(200).json({
        data: orders,
        message: "ok",
        error: false,
        success: true,
      });
    } else if (user.role === "ADMIN") {
      const orders = await orderModel.findAll();

      res.status(200).json({
        data: orders,
        message: "ok",
        error: false,
        success: true,
      });
    }
  } catch (error) {
    res.status(500).json({
      message: error,
      error: true,
      success: false,
    });
  }
};

// Admin update order status
const updateOrderStatus = async (req, res) => {
  try {
    const orderId = req.params.id;

    console.log("first", orderId);

    const { status } = req.body;

    if (!["PENDING", "COMPLETED", "CANCELLED"].includes(status)) {
      return res
        .status(400)
        .json({ success: false, message: "Invalid status" });
    }

    await orderModel.update({ status }, { where: { id: orderId } });

    res.status(200).json({
      success: true,
      message: "Order status updated successfully",
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Something went wrong... Please try again",
    });
  }
};

// User delete order
const deleteOrder = async (req, res) => {
  try {
    const orderId = req.params.id;

    await orderModel.destroy({ where: { id: orderId } });

    res.status(200).json({
      success: true,
      message: "Order deleted successfully",
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Something went wrong... Please try again",
    });
  }
};

module.exports = {
  createOrder,
  getOrderSummary,
  updateOrderStatus,
  deleteOrder,
};
