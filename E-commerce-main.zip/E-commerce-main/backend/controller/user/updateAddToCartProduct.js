const { addToCartModel } = require("../../models");

const updateAddToCartProduct = async (req, res) => {
  try {
    const currentUserId = req.userId;
    const addToCartProductId = req.body.id;
    const qty = req.body.quantity;

    // Update product using Sequelize
    const [affectedRows] = await addToCartModel.update(
      { quantity: qty },
      {
        where: {
          id: addToCartProductId,
          userId: currentUserId,
        },
      }
    );

    if (affectedRows === 0) {
      return res.json({
        message: "Product not found or no changes made",
        error: true,
        success: false,
      });
    }

    res.json({
      message: "Product Updated",
      data: { id: addToCartProductId, quantity: qty },
      error: false,
      success: true,
    });
  } catch (err) {
    res.json({
      message: err?.message || err,
      error: true,
      success: false,
    });
  }
};

module.exports = updateAddToCartProduct;
