const addToCartModel = require("../../models/cartProduct");
const { productModel } = require("../../models");

const addToCartViewProduct = async (req, res) => {
  try {
    const currentUser = req.userId;
    console.log("first", currentUser);

    const allProduct = await addToCartModel.findAll({
      where: { userId: currentUser },
      include: [
        {
          model: productModel,
          as: "product", // Ensure this matches any defined alias in the associations
          attributes: ["id", "productImage", "productName", "price", "category"],
        },
      ],
      order: [["createdAt", "DESC"]], // Optional: order results
    });

    console.log("allProduct", allProduct);

    res.json({
      data: allProduct,
      success: true,
      error: false,
    });
  } catch (err) {
    res.status(400).json({
      message: err.message || err,
      error: true,
      success: false,
    });
  }
};

module.exports = addToCartViewProduct;

