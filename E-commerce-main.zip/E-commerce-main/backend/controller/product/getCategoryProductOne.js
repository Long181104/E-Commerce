const { productModel } = require("../../models");

const getCategoryProduct = async (req, res) => {
  try {
    // Get distinct categories from the product table
    const productCategories = await productModel.findAll({
      attributes: ["category"],
      group: ["category"],
    });

    // Array to store one product from each category
    const productByCategory = [];

    for (const { category } of productCategories) {
      const product = await productModel.findOne({
        where: { category },
      });

      if (product) {
        productByCategory.push(product);
      }
    }

    res.json({
      message: "Category product",
      data: productByCategory,
      success: true,
      error: false,
    });
  } catch (err) {
    res.status(400).json({
      message: err.message || err,
      error: true,
      success: false,
    });
  }
};

module.exports = getCategoryProduct;

