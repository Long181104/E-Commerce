const { productModel } = require("../../models");

const filterProductController = async (req, res) => {
  try {
    const categoryList = req.body.category || [];

    const products = await productModel.findAll({
      where: {
        category: {
          [Op.in]: categoryList,
        },
      },
    });

    res.json({
      data: products,
      message: "Products retrieved successfully",
      error: false,
      success: true,
    });
  } catch (err) {
    res.json({
      message: err.message || err,
      error: true,
      success: false,
    });
  }
};

module.exports = filterProductController;
