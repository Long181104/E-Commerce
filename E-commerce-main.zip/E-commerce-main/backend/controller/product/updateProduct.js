const uploadProductPermission = require("../../helpers/permission");
const { productModel } = require("../../models");

async function updateProductController(req, res) {
  try {
    if (!uploadProductPermission(req.userId)) {
      throw new Error("Permission denied");
    }

    const { id, ...resBody } = req.body;

    const updateProduct = await productModel.update(resBody, {
      where: {
        id,
      },
    });

    res.json({
      message: "Product update successfully",
      data: updateProduct,
      success: true,
      error: false,
    });
  } catch (err) {
    res.status(400).json({
      message: err.message || err,
      error: true,
      success: false,
    });
  }
}

module.exports = updateProductController;

