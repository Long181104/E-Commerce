const { Op } = require("sequelize");
const { productModel } = require("../../models");

const searchProduct = async (req, res) => {
  try {
    const query = req.query.q;

    const products = await productModel.findAll({
      where: {
        [Op.or]: [
          { productName: { [Op.like]: `%${query}%` } },
          { category: { [Op.like]: `%${query}%` } },
        ],
      },
    });

    res.json({
      data: products,
      message: "Search Product list",
      error: false,
      success: true,
    });
  } catch (err) {
    res.status(400).json({
      message: err.message || err,
      error: true,
      success: false,
    });
  }
};

module.exports = searchProduct;

