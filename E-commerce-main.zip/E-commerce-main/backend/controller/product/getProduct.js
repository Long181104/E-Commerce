const { productModel } = require("../../models");

const getProductController = async (req, res) => {
  try {
    // Fetch all products sorted by 'createdAt' in descending order
    const allProducts = await productModel.findAll({
      order: [["createdAt", "DESC"]],
    });

    res.json({
      message: "All Products",
      success: true,
      error: false,
      data: allProducts,
    });
  } catch (err) {
    res.status(400).json({
      message: err.message || err,
      error: true,
      success: false,
    });
  }
};

module.exports = getProductController;

