const sql = require('mssql');
const dbConfig = require('./config.json').development;

const poolPromise = new sql.ConnectionPool(dbConfig)
  .connect()
  .then(pool => {
    console.log('Connected to MSSQL', 'INFO', 'DBContext');
    return pool;
  })
  .catch(err => console.error('Database connection failed:', err));

module.exports = {
  sql,
  poolPromise,
};
