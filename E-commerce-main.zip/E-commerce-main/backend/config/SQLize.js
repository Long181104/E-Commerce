const config = require("./config.json").development;
const Sequelize = require("sequelize");

const sequelize = new Sequelize(
  config.database,
  config.username,
  config.password,
  {
    dialect: "mssql",
    server: config.host,
    port: config.port,
    database: config.database,
    schema: config.schema,
    authentication: {
      type: "default",
      options: {
        userName: config.username,
        user: config.username,
        password: config.password,
      },
      pool: {
        max: config.pool.max,
        min: config.pool.min,
      },
    },
    logging: async (msg, object) => {
      let level;
      if (msg.includes("SequelizeDatabaseError")) level = "ERROR";
      else if (msg.startsWith("Executing")) level = "DEBUG";
      await console.log(msg, level, "sequelize");
    },
  }
);
console.log("Connecting to database...", "INFO", "sequelize");
if (sequelize) console.log("Connected to database", "INFO", "sequelize");
else console.log("Failed to connect to database", "ERROR", "sequelize");

console.log("Syncing tables...", "INFO", "sequelize");
sequelize
  .sync()
  .then(() => console.log("Tables synced", "INFO", "sequelize"))
  .catch((error) => console.log(error, "ERROR", "sequelize"));

module.exports = {
  sequelize,
  Sequelize,
};
